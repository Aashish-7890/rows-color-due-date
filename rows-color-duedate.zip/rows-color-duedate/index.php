<?php
// Database connection
$host = "localhost"; // Change if needed
$user = "root"; // Change if needed
$password = ""; // Change if needed
$database = "login"; // Change if needed

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Task List with Expiry Color Coding</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid black;
            padding: 10px;
            text-align: left;
        }

        .red {
            background-color: red;
            color: white;
        }

        .blue {
            background-color: blue;
            color: white;
        }

        .yellow {
            background-color: yellow;
        }

        .green {
            background-color: green;
            color: white;
        }
    </style>
</head>

<body>

    <h2>Task List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Oem</th>
            <th>Price</th>
            <th>Create Date</th>
            <th>Expiry Date</th>
        </tr>

        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $today = date("Y-m-d");
                $expiry_date = $row["expiry_date"];
                $days_due = (strtotime($expiry_date) - strtotime($today)) / (60 * 60 * 24);

                // Assign color based on due days
                if ($days_due >= 1 && $days_due <= 3) {
                    $color_class = "red";
                } elseif ($days_due > 3 && $days_due <= 31) {
                    $color_class = "blue";
                } elseif ($days_due > 31 && $days_due <= 45) {
                    $color_class = "yellow";
                } elseif ($days_due > 45 && $days_due <= 365) {
                    $color_class = "green";
                } else {
                    $color_class = ""; // No color if past due
                }

                echo "<tr class='$color_class'>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['oem_no']}</td>
                    <td>{$row['price']}</td>
                    <td>{$row['create_date']}</td>
                    <td>{$row['expiry_date']}</td>
                  </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No tasks found</td></tr>";
        }
        ?>

    </table>

</body>

</html>

<?php
$conn->close();
?>